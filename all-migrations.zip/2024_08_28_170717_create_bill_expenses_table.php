<?php

use App\Models\Supplier;
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\People;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bill_expenses', function (Blueprint $table) {
            $table->id();
            $table->string('bill_number')->unique(); 
            $table->integer('people_account_id');
            $table->integer('money_account_id');
            $table->date('bill_date'); 
            $table->decimal('paid',10,2)->default(0);
            $table->decimal('grand_total', 10, 2);
            $table->text('note')->nullable();
            $table->string('reference',20);
            $table->foreignIdFor(People::class,'supplier_id');
            $table->foreignIdFor(User::class);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bill_expenses');
    }
};